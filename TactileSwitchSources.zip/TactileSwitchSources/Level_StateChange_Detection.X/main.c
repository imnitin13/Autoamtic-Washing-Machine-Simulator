/*
 * File:   main.c
 * Author: Emertxe
 *
 * Created on August 2, 2021, 11:22 AM
 */


#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
     TRISD = 0x00;
     PORTD = 0x00;
  
    SW1_DDR = 1;
    
}

void main(void) {
    unsigned char key;
    init_config();
    while (1) {
       
        key = read_key(LEVEL); // Key -> ??
		if(key == 0)
		{
			LED1 = !LED1; // Action
            for(unsigned long int delay = 100000; delay--; );
			
		}
    }

}

char read_key(unsigned char mode)
{
	static char once = 1;
	if(mode == LEVEL)
	{
		if(RB0 == 0)
        {
			return 0;
		}
	}
	else
	{
		 if ((RB0 == 0) && once)  //RB0 
        {         
            once = 0;
			return 0;
        }
        else if (RB0 == 1) // RB0 == 1
        {
            once = 1;
        }
	}
	return 1;
}

