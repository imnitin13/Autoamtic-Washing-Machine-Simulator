/* 
 * File:   main.h
 * Author: Emertxe
 *
 * Created on August 2, 2021, 11:24 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#define SW1_DDR             TRISB0

#define LED1                RD0
#define SW1                 RB0


#define LEVEL   1
#define STATE   0

char read_key(unsigned char mode);


#endif	/* MAIN_H */

