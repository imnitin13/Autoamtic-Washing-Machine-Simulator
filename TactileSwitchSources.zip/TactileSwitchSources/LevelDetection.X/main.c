/*
 * File:   main.c
 */

#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

static void init_config(void) {
    TRISD = 0; // making PORTD as output
    PORTD = 0x00; // All LEDS OFF 
    SW1_DDR = 1; //Input
}

void main(void) {
    init_config();

    while (1) {
      //  if (SW1 == PRESSED) //RBo == 0
        if(RB0 == 0)
        {
            //take action
            LED1 = !LED1;
            for(unsigned long int delay = 100000; delay--;);
                           
        }
        
    }
    return;
}
