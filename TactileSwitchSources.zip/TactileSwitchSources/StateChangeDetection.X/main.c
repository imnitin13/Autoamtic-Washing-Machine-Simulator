/*
 * File:   main.c
 */

#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

static void init_config(void) {
    TRISD = 0x00;
    PORTD = 0x00;
  
    SW1_DDR = 1;
}

void main(void) {
    int once = 1;
    
    init_config();

    while (1) {
        if ((SW1 == PRESSED) && once)  //RB0 
        {
            LED1 = !LED1;
            
            once = 0;
        }
        else if (SW1 == RELEASED) // RB0 == 1
        {
            once = 1;
        }
    }
    return;
}
